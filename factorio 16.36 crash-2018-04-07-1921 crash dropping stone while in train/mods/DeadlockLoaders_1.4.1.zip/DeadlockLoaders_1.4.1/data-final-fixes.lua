local DCL = require("prototypes.shared")

-- speed check
if not DCL.PARADOX then
    for i=1,DCL.TIERS do
        if data.raw.loader["deadlock-loader-entity-"..i] and data.raw["transport-belt"][DCL.BELTS[i]] then
            data.raw.loader["deadlock-loader-entity-"..i].speed = data.raw["transport-belt"][DCL.BELTS[i]].speed
        end
    end
end