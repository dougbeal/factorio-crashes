script.on_event(defines.events.on_player_created, function(event)
	--Check for sandbox mode... or any mode without a player body.
	local player = game.players[event.player_index]
	if not player.character then
		return
	end
	
	genarmor(player)
end)

script.on_init(function(event)
	if settings.startup["TinyStart-init-spawn"].value then
		for _,player in pairs(game.players) do
			if player.character then
				genarmor(player)
			end
		end
	end
end)

script.on_event(defines.events.on_pre_player_crafted_item, function(event)
	local armor = event.items.find_item_stack("tiny-armor-mk0") or event.items.find_item_stack("tiny-armor-mk1")
	if armor then
		local player = game.players[event.player_index]
		local playermaininv = player.get_inventory(defines.inventory.player_main)
		local gridinventory = armor.grid.take_all()
		for gear, cnt in pairs(gridinventory) do
			local inserted = 0
			if playermaininv.can_insert({name=gear, count=cnt}) then
				inserted = playermaininv.insert({name=gear, count=cnt})
			end
			if inserted < cnt then
				--player.print("WARNING: Inventory full.")
				player.surface.spill_item_stack(player.position,{name=gear, count=cnt-inserted})
			end
		end
	end
end)


function genarmor(player)
	
	-- Since we now have the option to have armor added after map start/player creation
	-- we have to make sure something isn't already there.
	player.get_inventory(defines.inventory.player_armor).clear()
	-- Create armor and add grid equipment
	player.insert{name="tiny-armor-mk0", count = 1}
	addgear(player, player.get_inventory(defines.inventory.player_armor)[1].grid)
	
	-- Provide construction robots.
	player.insert{name="construction-robot", count = 20}
	
	-- Provide bluepints. Not needed since they aren't crafted anymore, but left here for convenience
	if settings.get_player_settings(player)["TinyStart-blueprint"].value then
		-- safety checks since we might be adding these to existing characters on an existing save.
		if player.get_inventory(defines.inventory.player_quickbar).can_insert({name="blueprint-book"}) then
			player.insert{name="blueprint-book", count = 1}
			local book = player.get_inventory(defines.inventory.player_quickbar).find_item_stack("blueprint-book").get_inventory(defines.inventory.item_main)
			book.insert{name="blueprint", count = 20}
		end
		if player.get_inventory(defines.inventory.player_quickbar).can_insert({name="deconstruction-planner"}) then
			player.insert{name="deconstruction-planner", count = 1}
		end
	end
	-- Marathon mode extra resources
	-- I have kind of mixed thoughts about this...
	-- will including this even as an option make the mod less appealing to some?
	-- But it is easier to have a setting than maintaining two variations in parallel...
	if settings.startup["TinyStart-marathon-start"].value then
		player.insert{name="stone-furnace", count = 24} --enough for half of a 24 smelter block, for copper and iron each
		player.insert{name="electric-mining-drill", count = 24}
		player.insert{name="steam-engine", count = 6}
		player.insert{name="boiler", count = 3}
		player.insert{name="small-electric-pole", count = 50}
		player.insert{name="transport-belt", count = 300}
		player.insert{name="offshore-pump", count = 1}
		player.insert{name="pipe-to-ground", count = 6}
		player.insert{name="pipe", count = 10}
		player.insert{name="inserter", count = 57}	--48 (furnaces) + 3 (boilers) + 6 (starter red science facility)
		player.insert{name="science-pack-1", count = 10 * game.difficulty_settings.technology_price_multiplier}
		player.insert{name="lab", count = 2}
	end
end

function addgear(player, grid)
	local config_fusion = settings.get_player_settings(player)["TinyStart-fusion-solar"].value
	local config_shield = fif(settings.get_player_settings(player)["TinyStart-shield"].value == "Shield", true, false)
	local config_battery = fif(settings.get_player_settings(player)["TinyStart-battery"].value == "Battery", true, false)

	if config_fusion == "Fusion" then
		grid.put({name = "micro-fusion-reactor-equipment"})
	elseif config_fusion == "Solar" then
		-- unlike most Lua stuff that starts counting from one, the equipment
		-- grid starts counting from 0. 0,0 is the top left slot.
		grid.put({name = "solar-panel-equipment", position = {0,0}})
		grid.put({name = "solar-panel-equipment", position = {0,1}})
		grid.put({name = "solar-panel-equipment", position = {1,0}})
		grid.put({name = "solar-panel-equipment", position = {1,1}})
	else
		grid.put({name = "stirling-solar-equipment"})
	end
	if config_shield then
		grid.put({name = "energy-shield-equipment"})
	else
		if config_fusion == "Stirling" then
			grid.put({name = "stirling-solar-equipment"})
		else
			grid.put({name = "solar-panel-equipment", position = {2,0}})
			grid.put({name = "solar-panel-equipment", position = {2,1}})
			grid.put({name = "solar-panel-equipment", position = {3,0}})
			grid.put({name = "solar-panel-equipment", position = {3,1}})
		end
	end
	if config_battery then
		grid.put({name = "battery-mk2-equipment"})
	else
		grid.put({name = "solar-panel-equipment", position = {4,0}})
		grid.put({name = "solar-panel-equipment", position = {4,1}})
	end
	grid.put({name = "battery-mk2-equipment", position = {4,2}})
	grid.put({name = "personal-roboport-equipment"})
	grid.put({name = "personal-roboport-equipment"})
end

function fif(condition, if_true, if_false)
  if condition then return if_true else return if_false end
end