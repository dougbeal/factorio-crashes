require("prototypes.tinyarmor")
require("prototypes.tinyarmor-recipes")