Tiny_Start 0.16.0 by Michael Cowgill (ChurchOrganist)

This is a port of Yehn's TinyStart mod for Factorio 0.16.
It gives the player very basic power armor with the necessary equipment to provide construction bots at the beginning of the game.

Yehn's original code is unchanged apart from alterations to the sprite definitions, required for compatibility with Factorio's 0.16.x format.

This has been tested in Sandbox mode appears to be working OK.
If not please file a bug report at the Github repository.

Hope you enjoy it :)

It is licensed under the MIT license, available in this package in the file  LICENSE.md.

Thank you to Yehn for writing the original TinyStart mod.

For more information on this licence please visit: http://opensource.org/licenses/mit-license.html
