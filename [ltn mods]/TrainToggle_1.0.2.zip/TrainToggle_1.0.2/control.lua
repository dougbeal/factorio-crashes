script.on_event("toggle-train-control", function(event)
        local player = game.players[event.player_index]
        local vehicle = player.vehicle
        if player.mod_settings.train_toggle_wagon_toggle.value then
            is_default = false
            if vehicle and vehicle.type == "locomotive" or "cargo-wagon" or "fluid-wagon" then
            vehicle.train.manual_mode = not vehicle.train.manual_mode
                if vehicle.train.manual_mode then
                player.print({"toggle-train-control-manual"})
                else
                player.print({"toggle-train-control-automatic"})
                end
            end
        else
            if vehicle and vehicle.type == "locomotive" then
                vehicle.train.manual_mode = not vehicle.train.manual_mode
                    if vehicle.train.manual_mode then
                        player.print({"toggle-train-control-manual"})
                    else
                        player.print({"toggle-train-control-automatic"})
                    end
            end
        end 
end)