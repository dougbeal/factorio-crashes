local prefix = "train_toggle_"
data:extend({
    {
        type = "bool-setting",
        name = prefix .. "wagon_toggle",
        setting_type = "runtime-per-user",
        order = "a",
        default_value = false
    }
})
