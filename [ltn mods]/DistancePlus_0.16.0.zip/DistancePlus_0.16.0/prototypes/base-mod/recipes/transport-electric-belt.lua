data:extend(
{
 {
    type = "recipe",
    name = "transport-electric-belt",
    enabled = "true",
    energy_required = 1,
    ingredients =
    {
        {"iron-plate", 1}
    },
    result_count = 5,
    result = "transport-electric-belt"
  }
 })