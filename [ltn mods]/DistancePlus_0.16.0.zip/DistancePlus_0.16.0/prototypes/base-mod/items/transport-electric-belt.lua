data:extend(
{
 {
    type = "item",
    name = transport-electric-belt",
    icon = "__base__/graphics/icons/transport-belt.png",
    icon_size = 32,
	flags = {"goes-to-quickbar"},
    subgroup = "energy-pipe-distribution",
    order = "a[transport-belt]-a[transport-belt]",
    place_result = "transport-electric-belt",
	fuel_value = "4MJ",
    stack_size = 50
  }
 })