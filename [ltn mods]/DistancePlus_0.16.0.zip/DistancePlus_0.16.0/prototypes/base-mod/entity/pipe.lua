local function createPipe( newName, distance )
	local pipeCopy = table.deepcopy(data.raw["pipe-to-ground"]["pipe-to-ground"])
	pipeCopy.name = newName
	pipeCopy.minable.result = newName
	pipeCopy.fluid_box.pipe_connections[2].max_underground_distance = distance
	
	return pipeCopy
end

data:extend
({
	createPipe("medium-pipe-to-ground", 30),
	createPipe("long-pipe-to-ground", 50),
	createPipe("ultra-pipe-to-ground", 120),
	createPipe("continental-pipe-to-ground", 255),
}
)