local function createBelt( baseName, newName, distance )
	local beltCopy = table.deepcopy(data.raw["underground-belt"][baseName])
	beltCopy.name = newName
	beltCopy.minable.result = newName
	beltCopy.fast_replaceable_group = "underground-belt"
	beltCopy.max_distance = distance
	
	return beltCopy
end

data:extend
({
	createBelt("underground-belt", "medium-underground-belt", 15),
	createBelt("underground-belt", "long-underground-belt", 30),
	createBelt("fast-underground-belt", "medium-fast-underground-belt", 15),
	createBelt("fast-underground-belt", "long-fast-underground-belt", 30),
	createBelt("express-underground-belt", "medium-express-underground-belt", 15),
	createBelt("express-underground-belt", "long-express-underground-belt", 30),
}
)