data:extend({
    {
        type = "bool-setting",
        name = "deadlock-crating-logging",
		order = "z",
        setting_type = "startup",
        default_value = false
    }
})