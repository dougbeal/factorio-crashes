table.insert(
data.raw["technology"]["automation"].effects,
{type = "unlock-recipe",recipe = "recycling-machine-1"}
)
table.insert(
data.raw["technology"]["automation-2"].effects,
{type = "unlock-recipe",recipe = "recycling-machine-2"}
)
table.insert(
data.raw["technology"]["automation-3"].effects,
{type = "unlock-recipe",recipe = "recycling-machine-3"}
)